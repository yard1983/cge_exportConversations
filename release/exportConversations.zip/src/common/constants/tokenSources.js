const purecloud = 'purecloud';
const cognito = 'cognito';

module.exports = {
    purecloud,
    cognito
}